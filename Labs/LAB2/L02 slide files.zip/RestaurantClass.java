package L02_Slides;
import java.util.Arrays;
import java.util.List;

public class RestaurantClass {

	final List<String> restaurants = 
			Arrays.asList("Olive Garden", "El Fenix", "Abuelos", 
					      "Chili's", "Kincaids", "Edelweiss");
}